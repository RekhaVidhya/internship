#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import io
import numpy as np
import math
import warnings


# In[3]:


import math
def factorial(n):
    if n < 0:
        return 0
    elif n == 0 or n == 1:
        return 1
    else:
        fact = 1
        while(n > 1):
            fact *= n
            n -= 1
        return fact
 
num = 5;
print("Factorial of",num,"is",factorial(num))
 


# # Prime or Composite

# In[18]:


N=int(input("Enter a Number :"))
if N<1:
    print(" Please enter number greater than 1")
elif N == 1:
        print(N,"is neither Prime nor Composite")
else:
    for i in range(2,(N//2)+1):
        if (N%i)==0:
            print(N," is composite Number")
        break
    else: 
        print(N," is a Prime Number")


# # Palindrome

# In[22]:


String=input("Enter a String:")
Reverse=String[::-1]
if Reverse==String:
    print(String,"is a Palindrome")
else:
    print(String,"is not a Palindrome")


# # Third side of Right Angled Triangle

# In[34]:


from math import sqrt
Side=input("Enter which side has to be calculated O(Opposite),A(Adjacent),H(Hypotenuse):")
if (Side=="O"):
    A=input("Enter A value :")
    H=input("Enter H Value :")
    O=sqrt((H*H)-(A*A))
    print("The value of O is",O)
elif (Side=="A"):
    O=input("Enter O value :")
    H=input("Enter H Value :")
    A=sqrt((H*H)-(O*O))
    print("The value of A is",A)
else:
    O=int(input("Enter O value :"))
    A=int(input("Enter A Value :"))
    H=sqrt((A*A)+(O*O))
    print("The value of H is",H)


# # Count of characters in a String

# In[44]:


String=input("Enter a String :")
Dictionary=dict()
for i in String:
    Dictionary[i]=Dictionary.get(i, 0) + 1
print(Dictionary)


# In[ ]:





# In[ ]:




